# Design System Strategy: Calculated Precision

## 1. Overview & Creative North Star
**The Creative North Star: "The Grandmaster’s Ledger"**

This design system rejects the cluttered, "noisy" aesthetics of traditional SaaS dashboards. Instead, it adopts a high-end editorial approach that mirrors the quiet confidence of a seasoned strategist. The "Calculated Moves" theme is executed through **The Grandmaster’s Ledger**—a visual metaphor where data isn't just displayed; it is curated.

We break the "template" look by utilizing **intentional asymmetry** and **high-contrast typography scales**. By pairing the structural rigor of a geometric sans-serif (Manrope) with the functional clarity of Inter, we create an experience that feels like a bespoke financial broadsheet rather than a generic software tool. We favor expansive white space and "breathing rooms" over dense grids, allowing critical "odds" and growth metrics to command the user's focus.

---

## 2. Colors & Surface Philosophy
The palette is rooted in the deep, felted greens of a high-stakes environment, balanced by a pristine, gallery-like background.

*   **Primary (`#003528`) & Primary Container (`#0A4D3C`):** These represent the "Table." Use them for high-impact moments and primary navigation.
*   **Secondary (`#B6171E`):** The "Burn Card." Use sparingly for critical alerts, negative trends, or high-urgency CTAs.
*   **Neutral Surfaces (`#F9F9F8` to `#E1E3E2`):** A sophisticated range of off-whites and cool greys that provide the "Paper" for our ledger.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to define sections. Boundaries must be defined solely through background color shifts. For example, a `surface-container-low` sidebar sitting against a `surface` background provides all the definition a user needs without the "boxed-in" feeling of a wireframe.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. 
*   **Level 0 (Background):** `surface` (#f9f9f8).
*   **Level 1 (Sections):** `surface-container-low` (#f3f4f3).
*   **Level 2 (Interactive Cards):** `surface-container-lowest` (#ffffff).
By placing a "lowest" (brightest) card on a "low" (slightly darker) section, we create natural depth through tonal contrast alone.

### The "Glass & Gradient" Rule
To elevate the dashboard from "Standard UI" to "Signature Experience," use **Glassmorphism** for floating elements (e.g., "Deep Dive" spade-icon modals). Use `surface-container-lowest` at 80% opacity with a `20px` backdrop blur. 
*   **Signature Texture:** Main CTAs should use a subtle linear gradient from `primary` (#003528) to `primary-container` (#0A4D3C) at a 135° angle to add "visual soul" and a tactile, premium finish.

---

## 3. Typography: Editorial Authority
We use a dual-font system to balance character with readability.

*   **Display & Headlines (Manrope):** High-impact, geometric, and authoritative. 
    *   *Usage:* Use `display-lg` for hero growth percentages and `headline-sm` for section titles. The wide aperture of Manrope conveys a sense of modern scale.
*   **Body & Labels (Inter):** The workhorse. 
    *   *Usage:* All data points, tooltips, and long-form insights use Inter. 
    *   *Hierarchy:* Use `label-md` for "Odds" or "Risk" tags, often tracked with `letter-spacing: 0.05rem` to mimic professional typesetting.

---

## 4. Elevation & Depth
In this system, shadows are a last resort, not a default.

*   **The Layering Principle:** Stacking `surface-container` tiers is the primary method of elevation. An inner container should always be visually "lighter" (closer to #ffffff) than its parent to appear closer to the user.
*   **Ambient Shadows:** For floating elements like dropdowns or "Chip" credit selectors, use the following:
    *   *Blur:* 32px to 48px.
    *   *Opacity:* 4% - 6% of `on-surface` (#191c1c).
    *   *Result:* A soft, atmospheric glow that feels like natural light, not a digital drop-shadow.
*   **The Ghost Border:** If a boundary is required for accessibility (e.g., input fields), use `outline-variant` at **15% opacity**. Never use a 100% opaque border.

---

## 5. Components

### Buttons: The "Calculated" Interaction
*   **Primary:** Gradient fill (`primary` to `primary-container`), `md` (12px) roundedness, white text.
*   **Secondary:** `surface-container-high` background with `on-surface` text. No border.
*   **Tertiary:** Ghost style. Text only, shifting to `surface-container-low` on hover.

### Cards & Lists: The No-Divider Policy
*   **Forbid the use of horizontal divider lines.** 
*   Separate list items using the **Spacing Scale**. A `3 (1rem)` gap between items on a `surface-container-lowest` background creates a cleaner, more premium rhythm.
*   For data tables, use alternating tonal rows (`surface` vs `surface-container-low`) instead of lines.

### Specialized Components
*   **The "Odds" Badge:** A small, pill-shaped component (`full` roundedness) using `secondary-container` for low probability or `primary-fixed` for high probability.
*   **The "Spade" Deep Dive:** A floating action button (FAB) or icon trigger that uses the Glassmorphism rule to overlay detailed analytics without losing context of the main dashboard.
*   **Growth Chips:** Used for credits or quick-filters. Use `sm` (4px) or `DEFAULT` (8px) corners to distinguish them from the rounder, "safer" action buttons.

---

## 6. Do’s and Don’ts

### Do
*   **DO** use `16 (5.5rem)` or `20 (7rem)` spacing for top-level margins. Generosity with space is the ultimate sign of luxury.
*   **DO** use asymmetric layouts. Place a large `display-md` metric on the left and a cluster of `body-sm` insights on the right to create an editorial flow.
*   **DO** use subtle poker metaphors in iconography (e.g., a "chip" icon for account balance) but keep the line weight thin (`1px` or `1.5px`).

### Don’t
*   **DON'T** use pure black (#000000). Always use `on-surface` (#191c1c) to maintain tonal softness.
*   **DON'T** use "Standard" shadows. If the component looks like it's "popping" off the screen, the shadow is too dark.
*   **DON'T** use 100% saturated reds. Use our `secondary` (#B6171E) which is slightly desaturated and "blood-like," fitting the high-end poker aesthetic.